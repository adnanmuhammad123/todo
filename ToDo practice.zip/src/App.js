import React, { Component }  from "react";
import "./App.css";
import ToDo from "./components/screens/ToDo";
class App extends Component {
  render() {
    return <ToDo/>
  } 
}                                                  
export default App; 
     